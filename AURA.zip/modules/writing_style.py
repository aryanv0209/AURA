# Analyze writing style using GPT
