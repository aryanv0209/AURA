# Estimate sleep/wake patterns from post times
