# Create graphs and visuals
