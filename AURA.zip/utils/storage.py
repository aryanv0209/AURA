# Save data to local storage
