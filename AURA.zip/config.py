# Configuration settings like user-agent, timeouts, etc.
